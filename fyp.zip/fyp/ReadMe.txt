Instructions to run website:

Step 1: Upgrade and install pip using the following command: pip install --upgrade pip

Step 2: Install django using the following command: pip install django

Step 3: THen run the server using the following command: python manage.py runserver

Step 4: Type in this url to access website http://127.0.0.1:8000/


