from sqlite3 import Date
from telnetlib import STATUS
from unicodedata import category
from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Customer(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    FName = models.CharField(max_length=200, null=True)
    
    Email = models.EmailField(max_length=30, null=True)
    Password = models.CharField(max_length=30, null=True)
    Number = models.BigIntegerField(max_length=30, null=True)
    JobPreference = models.CharField(max_length=30, null=True)



    def __str__(self):
        return self.FName

class Freelancer(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    FName = models.CharField(max_length=200, null=True)
    username = models.CharField(max_length=200, null=True)
    Email = models.EmailField(max_length=30, null=True)
    Password = models.CharField(max_length=30, null=True)
    Number = models.BigIntegerField(max_length=30, null=True)
    JobPreference = models.CharField(max_length=30, null=True)
    Link = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.FName


class Preference(models.Model):

    FName = models.CharField(max_length=200, null=True)
 

    def __str__(self):
        return self.FName

class Service(models.Model):
    CAT = (
        ('In-Person','In-Person'),
        ('Online Design','Online Design'),
        ( 'Content Creation','Content Creation'),
        ('Music', 'Music'),)

    STAT= (
        ('Confirmed','Confirmed'),
        ('In Progress','In Progress'),
        ( 'Finished','Finished'),
        )

    ServiceName = models.CharField(max_length=200, null=True)
    

    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    LowestPrice = models.FloatField( null=True)
    HighestPrice = models.FloatField( null=True)
    CAT1 = models.CharField(max_length=30, null=True, choices=CAT)
    Description = models.CharField(max_length=30, null=True)
    Country = models.CharField(max_length=30, null=True)
    City = models.CharField(max_length=30, null=True)
    creation_date= models.DateTimeField(auto_now_add=True, null=True)
    status1= models.CharField(max_length=200, null=True, choices=STAT )
        
    def __str__(self):
        return self.ServiceName

class Service_Status(models.Model):
    STAT= (
        ('Confirmed','Confirmed'),
        ('In Progress','In Progress'),
        ( 'Finished','Finished'),
        )
    customer=models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    ConfirmCustomerName=models.CharField(max_length=200, null=True)
    service=models.ForeignKey(Service, null=True, on_delete=models.SET_NULL)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    creation_date= models.DateTimeField(auto_now_add=True, null=True)
    status1= models.CharField(max_length=200, null=True, choices=STAT )
    
    PriceAgreed = models.BigIntegerField(null=True)

    def __str__(self):
        return self.service.ServiceName




class Feedback(models.Model):
    ScoreNum= (
        ('1','1'),
        
        ('2','2'),
        ( '3','3'),
        ( '4','4'),
        ( '5','5'),
        )

    ConfirmYourName=models.CharField(max_length=200, null=True)
    service=models.ForeignKey(Service, null=True, on_delete=models.SET_NULL)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    creation_date= models.DateTimeField(auto_now_add=True, null=True)
    Feedback = models.CharField(max_length=200, null=True)
    Score = models.CharField(max_length=30, null=True, choices=ScoreNum, default='1' )
    


class Messages(models.Model):
    

    ConfirmYourName=models.CharField(max_length=200, null=True)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    service=models.ForeignKey(Service, null=True, on_delete=models.SET_NULL)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    creation_date= models.DateTimeField(auto_now_add=True, null=True)
    message = models.CharField(max_length=200, null=True)
    
    

class Service_Request(models.Model):
    STATUS= (
        ('Accepted','Accepted'),
        ('Denied','Denied'),
        ('Pending','Pending'),
        
        )

    ConfirmYourName=models.CharField(max_length=200, null=True)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    service=models.ForeignKey(Service, null=True, on_delete=models.SET_NULL)
    freelancer=models.ForeignKey(Freelancer, null=True, on_delete=models.SET_NULL)
    AgreedPrice=models.FloatField( null=True)
    status1= models.CharField(max_length=200, null=True, choices=STATUS )
    message=models.CharField(max_length=200, null=True)


class AdminMessage(models.Model):
    

    YourName=models.CharField(max_length=200, null=True)
    Email = models.EmailField(max_length=30, null=True)
    Issue = models.CharField(max_length=200, null=True)
    
    RelatedPage = models.CharField(max_length=200, null=True)

    creation_date= models.DateTimeField(auto_now_add=True, null=True)
    
    
    