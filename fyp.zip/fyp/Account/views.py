from django.shortcuts import render, redirect
from django.http import HttpResponse
# Create your views here.
from .models import *
from django.contrib.auth.forms import UserCreationForm
from .forms import Feedbacker, serviceStat, serviceProvided, createFreelancer, serviceRequest, sendMessage, Feedbacker, changeFreelancer, adminHelp, addFreelancerDetails, RequestUpdate
from .filter import Filter
from django.contrib import messages
from django.contrib.auth import authenticate, logout, login
from django.contrib.auth.decorators import login_required
def createAccount(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form=createFreelancer()

        if request.method == 'POST':
            form=createFreelancer(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'Account Created Succesfully, please login')
                return redirect('createDetails')
        data={'form':form}
        return render(request, 'Account/createAccount.html', data)

def loginP(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method== 'POST':
            username = request.POST.get('username')
            password=request.POST.get('password')
            user=authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, 'Details entered are wrong')
                
        data={}
        return render(request, 'Account/login.html', data)

def logoutAcc(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def home(request):
    
    freelancers= Freelancer.objects.all()
    customer = Customer.objects.all()

    services= Service.objects.all()

    serviceNum= services.count()

    # serviceStatus= Service_Status.objects.all()


    # ssService= serviceStatus.service.all()

    # ssFreelancer= serviceStatus.freelancer.all()

    service_status = Service_Status.objects.all()


    numFreelancer= freelancers.count()
    
    
    feedback=Feedback.objects.all

    messages=  Messages.objects.all
    requests = Service_Request.objects.all
    # ssFreelancer= services.service_status_set.all()
    order_delivered= services.filter(status1='Finished').count()
    order_pending= services.filter(status1='In Progress').count()
    data={ 'service_status':service_status, 'customer':customer,   
    'freelancers':freelancers, 'services':services, 'serviceNum':serviceNum,

    'numFreelancer':numFreelancer, 'order_delivered':order_delivered,

    'order_pending':order_pending, 'feedback':feedback, 'messages': messages, 'requests':requests
    
    
    }
    return render(request, 'Account/home.html', data)


def search(request):
    service= Service.objects.all()
    filterer=Filter(request.GET, queryset=service)
    service=filterer.qs
    data={'filterer':filterer,'service':service }
    return render(request, 'Account/search.html', data)


@login_required(login_url='login')
def customer(request, primaryKey):
    
    service_status = Service_Status.objects.all
    feedback=Feedback.objects.all
    customer=Freelancer.objects.get(id=primaryKey)
    # service_status_for_each_customer = Service_Status.objects.all()
    service_status_for_each_customer = customer.service_status_set.all()
    count=service_status_for_each_customer.count()
    data={'customer':customer, 'numService':service_status_for_each_customer, 'count':count, 
    'service_status':service_status, 'feedback':feedback}
    return render(request, 'Account/customer.html', data)

@login_required(login_url='login')
def mine(request, primaryKey):
    
    service_status = Service_Status.objects.all

    customer=Freelancer.objects.get(id=primaryKey)
    # service_status_for_each_customer = Service_Status.objects.all()
    service_status_for_each_customer = customer.service_status_set.all()
    count=service_status_for_each_customer.count()
    data={'customer':customer, 'numService':service_status_for_each_customer, 'count':count, 
    'service_status':service_status}
    return render(request, 'Account/myprofile.html', data)

def about(request):
    return render(request, 'Account/about.html')

@login_required(login_url='login')
def serviceCreate(request):

    form=serviceStat()
    if request.method=='POST':
        form=serviceStat(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/about')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)

@login_required(login_url='login')
def serviceCreateCustomer(request, primaryKey):
    customer= Customer.objects.get(id=primaryKey)
    form=serviceStat()
    if request.method=='POST':
        form=serviceStat(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)
@login_required(login_url='login')
def serviceUpdate(request, primaryKey):
    serviceSta = Service_Status.objects.get(id=primaryKey)
    form=serviceStat(instance=serviceSta)
    if request.method=='POST':
        form=serviceStat(request.POST, instance=serviceSta)
        if form.is_valid():
            form.save()
            return redirect('/')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)

@login_required(login_url='login')
def serviceDelete(request, primaryKey):
    serviceSta = Service_Status.objects.get(id=primaryKey)
    if request.method == "POST":
        serviceSta.delete()
        return redirect('/')
    data={'service':serviceSta}

    return render(request, 'Account/delete.html', data)


@login_required(login_url='login')
def serviceCreate1(request):
    form=serviceProvided()
    if request.method=='POST':
        form=serviceProvided(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)
@login_required(login_url='login')
def serviceUpdate1(request, primaryKey):
    lost = Service.objects.get(id=primaryKey)
    form=serviceProvided(instance=lost)
    if request.method=='POST':
        form=serviceProvided(request.POST, instance=lost)
        if form.is_valid():
            form.save()
            return redirect('/')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)

@login_required(login_url='login')
def serviceDelete1(request, primaryKey):
    serviceProvided = Service.objects.get(id=primaryKey)
    if request.method == "POST":
        serviceProvided.delete()
        return redirect('/')
    data={'service':serviceProvided}

    return render(request, 'Account/delete2.html', data)


@login_required(login_url='login')
def orderService(request):
    form=serviceRequest()
    if request.method=='POST':
        form=serviceRequest(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/search')
    
    data={'form':form}
    return render(request, 'Account/request.html', data)

@login_required(login_url='login')
def sendMessages(request):
    form=sendMessage()
    if request.method=='POST':
        form=sendMessage(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/search')
    
    data={'form':form}
    return render(request, 'Account/request.html', data)



@login_required(login_url='login')
def LeaveFeedback(request):
    form=Feedbacker()
    if request.method=='POST':
        form=Feedbacker(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/about')
    
    data={'form':form}
    return render(request, 'Account/request.html', data)



@login_required(login_url='login')
def updateDetails(request, primaryKey):
    lost = Freelancer.objects.get(id=primaryKey)
    form=changeFreelancer(instance=lost)
    if request.method=='POST':
        form=changeFreelancer(request.POST, instance=lost)
        if form.is_valid():
            form.save()
            return redirect('/about')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)


def sendAdminmessage(request):
    form=adminHelp()
    if request.method=='POST':
        form=adminHelp(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/about')
    
    data={'form':form}
    return render(request, 'Account/request.html', data)

    



def createDetails(request):
    form=addFreelancerDetails()
    if request.method=='POST':
        form=addFreelancerDetails(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    
    data={'form':form}
    return render(request, 'Account/request.html', data)




@login_required(login_url='login')
def changeStatus(request, primaryKey):
    lost = Service_Request.objects.get(id=primaryKey)
    form=RequestUpdate(instance=lost)
    if request.method=='POST':
        form=RequestUpdate(request.POST, instance=lost)
        if form.is_valid():
            form.save()
            return redirect('/')
    
    data={'form':form}
    return render(request, 'Account/staus_form.html', data)