from django.urls import path
from . import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('', views.home, name="home"),
    path('search/', views.search, name="search"),
    path('customer/<str:primaryKey>/', views.customer, name="customer"),
    path('mine/<str:primaryKey>/', views.mine, name="mine"),
    path('about/', views.about, name="about"),
    path('serviceCreate/', views.serviceCreate, name="serviceCreate"),
    path('serviceCreate1/', views.serviceCreate1, name="serviceCreate1"),
    path('serviceCreateCustomer/<str:primaryKey>/', views.serviceCreateCustomer, name="serviceCreateCustomer"),
    path('serviceUpdate/<str:primaryKey>/', views.serviceUpdate, name="serviceUpdate"),
    path('serviceUpdate1/<str:primaryKey>/', views.serviceUpdate1, name="serviceUpdate1"),
    path('serviceDelete/<str:primaryKey>/', views.serviceDelete, name="serviceDelete"),
    path('serviceDelete1/<str:primaryKey>/', views.serviceDelete1, name="serviceDelete1"),
    path('login/', views.loginP, name="login"),
    path('createAccount/', views.createAccount, name="createAccount"),
    path('logout/', views.logoutAcc, name="logout"),
    path('orderService/', views.orderService, name="orderService"),
    path('sendMessages/', views.sendMessages, name="sendMessages"),
    path('feed/', views.LeaveFeedback, name="feed"),
    path('updateDetails/<str:primaryKey>/', views.updateDetails, name="updateDetails"),
    path('sendAdminmessage/', views.sendAdminmessage, name="sendAdminmessage"),
    path('createDetails/', views.createDetails, name="createDetails"),
    path('changeStatus/<str:primaryKey>/', views.changeStatus, name="changeStatus")
]