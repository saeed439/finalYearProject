from django.contrib import admin

# Register your models here.
from .models import *
admin.site.register(Customer)
admin.site.register(Freelancer)
admin.site.register(Preference)

admin.site.register(Service)
admin.site.register(Service_Status)

admin.site.register(Feedback)
admin.site.register(Messages)

admin.site.register(Service_Request)
admin.site.register(AdminMessage)