from codecs import lookup_error
from dataclasses import fields
import django_filters
from django_filters import DateFilter, CharFilter

from .models import * 


class Filter(django_filters.FilterSet):
    ServiceName=CharFilter(field_name='ServiceName', lookup_expr='icontains')
    Country=CharFilter(field_name='Country', lookup_expr='icontains')
    City=CharFilter(field_name='City', lookup_expr='icontains')
    class Meta:
        model= Service
        fields='__all__'
        exclude = ['status1','creation_date', 'freelancer','Description' ]



       