from django import forms
from django.forms import ModelForm
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User

class serviceStat(ModelForm):
    class Meta:
        model=Service_Status
        fields='__all__'

class serviceProvided(ModelForm):
    class Meta:
        model=Service
        fields='__all__'


class createFreelancer(UserCreationForm):
    class Meta:
        model=User

        fields=['username', 'email', 'password1','password2' ]

class serviceRequest(ModelForm):
    class Meta:
        model=Service_Request
        fields=['ConfirmYourName','freelancer', 'service', 'AgreedPrice','message']

class sendMessage(ModelForm):
    class Meta:
        model=Messages
        fields=['ConfirmYourName','freelancer', 'service', 'message']

class Feedbacker(ModelForm):
    class Meta:
        model=Feedback
        fields=['ConfirmYourName','freelancer', 'service', 'Feedback', 'Score']


class changeFreelancer(ModelForm):
    class Meta:
        model=Freelancer

        fields=['FName','Number', 'JobPreference', 'Link']


class adminHelp(ModelForm):
    class Meta:
        model=AdminMessage
        fields=['YourName','Email', 'Issue', 'RelatedPage']

class addFreelancerDetails(ModelForm):
    class Meta:
        model=Freelancer
        fields='__all__'

class RequestUpdate(ModelForm):
    class Meta:
        model=Service_Request
        fields=['ConfirmYourName', 'service', 'AgreedPrice','message','status1']
